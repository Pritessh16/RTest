### Calculate differnece between MINIMUM & MAXIMUM:
### Author: Pritesh Acharya
### File: calc_range.R

#' @param x Numeric vector
#' @return Difference Maximum - MininuM
#' @export
calc_range <- function(x) {
  max(x) - min(x)
}
