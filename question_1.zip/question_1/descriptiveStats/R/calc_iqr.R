### Calculate INTERQUARTILE RANGE:
### Author: Pritesh Acharya
### File: calc_iqr.R

#' @param x Numeric vector
#' @return iqr value
#' @export
calc_iqr <- function(x) {
  IQR(x)
}
