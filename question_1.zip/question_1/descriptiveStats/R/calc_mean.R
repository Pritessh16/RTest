### Calculate MEAN:
### Author: Pritesh Acharya
### File: calc_mean.R

#' @param x Numeric vector
#' @return Mean value
#' @export
calc_mean <- function(x) {
  if(!is.numeric(x)) stop("Input must be numeric")
  sum(x) / length(x)
}
