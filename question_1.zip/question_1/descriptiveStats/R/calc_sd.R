### Calculate STANDARD DEVIATION:
### Author: Pritesh Acharya
### File: calc_sd.R

#' @param x Numeric vector
#' @return Standard deviation
#' @export
calc_sd <- function(x) {
  sqrt(calc_variance(x))
}
