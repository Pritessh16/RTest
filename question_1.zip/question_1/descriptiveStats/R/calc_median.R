### Calculate MEDIAN:
### Author: Pritesh Acharya
### File: calc_median.R

#' @param x Numeric vector
#' @return Median value
#' @export
calc_median <- function(x) {
  x <- sort(x)
  n <- length(x)
  
  if(n %% 2 == 0) {
    return((x[n/2] + x[n/2 + 1]) / 2)
  } else {
    return(x[(n+1)/2])
  }
}
