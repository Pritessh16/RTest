### Calculate SUMMARY STATISTICS:
### Author: Pritesh Acharya
### File: calc_summary.R

#' @param x Numeric vector
#' @return Data frame of descriptive statistics
#' @export
calc_summary <- function(x) {
  data.frame(
    Mean = calc_mean(x),
    Median = calc_median(x),
    Mode = calc_mode(x),
    Variance = calc_variance(x),
    SD = calc_sd(x),
    Range = calc_range(x),
    q1=calc_q1(x),
    q3=calc_q3(x)
  )
}
