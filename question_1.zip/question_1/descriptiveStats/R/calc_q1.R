### Calculate FIRST QUARTILE(Q1):
### Author: Pritesh Acharya
### File: calc_q1.R

#' @param x Numeric vector
#' @return q1 value
#' @export
calc_q1 <- function(x) {
  quantile(x, 0.25)
}