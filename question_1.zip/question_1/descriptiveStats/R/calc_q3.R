### Calculate THIRD QUARTILE(Q3):
### Author: Pritesh Acharya
### File: calc_q3.R

#' @param x Numeric vector
#' @return q3 value
#' @export
calc_q3 <- function(x) {
  quantile(x, 0.75)
}