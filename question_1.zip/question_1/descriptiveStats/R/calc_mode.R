### Calculate MODE:
### Author: Pritesh Acharya
### File: calc_mode.R

#' @param x Numeric vector
#' @return Mode value
#' @export
calc_mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
