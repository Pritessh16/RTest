### Calculate VARIANCE:
### Author: Pritesh Acharya
### File: calc_variance.R

#' @param x Numeric vector
#' @return Variance
#' @export
calc_variance <- function(x) {
  m <- mean(x)
  sum((x - m)^2) / (length(x) - 1)
}
