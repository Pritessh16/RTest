### createPackages.R: Creates Custom R Packages required in the test.
### Author: Pritesh Acharya
### File: createPackages.R

# Step 1: Install and load the needed packages.
install.packages(c("devtools", "usethis", "roxygen2"), quiet = TRUE)
library(usethis)
library(devtools)
library(roxygen2)

# Step 2: Create the package descriptiveStats to perform various summary statistics.
create_package(
  path = "/cloud/project/question_1/descriptiveStats",
  fields = list(
    Title = "R Package Development - Descriptive Statistics",
    Version = "0.1",
    Description = "Provides easy-to-use functions for descriptive statistics:
                  mean, median, mode, sd, variance, range, q1, q3, iqr and a full summary.",
    License = "OpenSouRce",
    `Authors@R` = 'person("Pritesh", "Acharya", , "pritessh.acharya@gmail.com", role = c("aut","cre"))'
  ),
  open = TRUE
)



