### gethubpub.R: Linking & Publication to GitHub Repository.
### Author: Pritesh Acharya
### File: githubpub.R

install.packages("usethis")
install.packages("devtools")
install.packages("gitcreds")

library(usethis)

usethis::use_git_config(
  user.name = "Pritesh Acharya",
  user.email = "pritessh.acharya@gmail.com"
)

# Create GitHub Token (Authentication)
# usethis::create_github_token()

# Assign token
#gitcreds::gitcreds_set(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)


