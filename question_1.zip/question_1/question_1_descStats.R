### Question 1: R Package Development - Descriptive Statistics
### Author: Pritesh Acharya
### File: question_1_descStats.R

#setwd to set the location of the Custome Package.
setwd("/cloud/project/question_1")

#getwd to verify set working directory. 
getwd()

install.packages("roxygen2")
# Calculate mean, median, mode, sd, variance, range, q1, q3, iqr and a full summary.
# Install & Load descriptiveStats Custom Package
install.packages("devtools")
library(devtools)
devtools::document("descriptiveStats")
devtools::install("descriptiveStats")
library(descriptiveStats)

# List Package Items:
ls("package:descriptiveStats")

# Data 1: Set numeric velues for Vector X.
# <- c(483, 712, 159, 905, 641, 327, 888, 204, 756, 390)
# Data 2: Set float velues for Vector X.
  x <- c(5.2, 6.1, 7.4, 6.8, 5.9, 7.0, 6.5, 0.1, 4.4, 9.9)
# Data 3: 10 samples between 100 to 999
# x <- sample(100:999, 10)

# mean from calc_mean.R
cat("Mean:", calc_mean(x), "\n")
# median from calc_median.R
cat("Median:", calc_median(x), "\n")
# mode from calc_mode.R
cat("Mode:", calc_mode(x), "\n")
# variance from calc_variance.R
cat("Variance:", calc_variance(x), "\n")
# sd from calc_sd.R
cat("Standard Deviation:", calc_sd(x), "\n")
# range from calc_range.R
cat("Range:", calc_range(x), "\n")
# Q1 from calc_q1.R
cat("Q1:", calc_q1(x), "\n")
# Q3 from calc_q3.R
cat("Q3:", calc_q3(x), "\n")
# IQR from calc_iqr.R
cat("IQR:", calc_iqr(x), "\n")

#--------------------------------------------
# Summary Statistics from calc_summary.R
calc_summary(x)
#--------------------------------------------

