### question_2_SDTM.R: Create an SDTM Disposition (DS) domain dataset from raw clinical trial data using the {sdtm.oak}.
### Author: Pritesh Acharya
### File: question_2_SDTM.R

# Standard Libraries. 
library(pharmaverseraw)
library(sdtm.oak)
library(dplyr)
library(lubridate)
library(labelled)
library(haven)
library(stringr)

# 1. Create DM Domain Function (To get exact subject count and Reference Dates.)
create_dm_domain <- function(studyid = "CDISCPILOT01") {
  message("Creating DM domain...")
  
  # Load DM_RAW from the PHARMAVERSERAW.
  dm_raw <- pharmaverseraw::dm_raw
  
  # Build required variables One By One using DM_RAW.
  dm <- dm_raw %>%
    
    # oak_id_vars
    generate_oak_id_vars(pat_var = "PATNUM", raw_src = "dm_raw") %>%
    
    # Identifiers
    mutate(
      STUDYID = studyid,
      DOMAIN  = "DM",
      USUBJID = paste0(STUDYID, "-", patient_number),
      RFSTDTC = format(mdy(COL_DT), "%Y-%m-%d")
    ) %>%
    
    select(STUDYID, DOMAIN, USUBJID, RFSTDTC, everything())
  
  # Assign SDTM Variable labels
  dm <- set_variable_labels(dm,
                            STUDYID = "Study Identifier",
                            DOMAIN  = "Domain Abbreviation",
                            USUBJID = "Unique Subject Identifier",
                            RFSTDTC = "Subject Reference Start Date/Time"
  )
  
  # Assign Dataset label
  attr(dm, "label") <- "DM - Demographics Domain"
  
  message("✓ DM domain created (", nrow(dm), " rows)")
  return(dm)
}

# -----------------------------------------------------

# 2. Create DS Domain Function (To build requested SDTM dataset.)
create_ds_domain <- function(dm, studyid = "CDISCPILOT01") {
  
  message("Creating DS domain...")
  
  # Load DS_RAW from the PHARMAVERSERAW.
  ds_raw <- pharmaverseraw::ds_raw
  
  # Build required variables One By One using DM_RAW.
  
  # Create dates
  ds1 <- ds_raw
  ds1$DSDTC   <- format(mdy(ds1$DSDTCOL), "%Y-%m-%d")
  ds1$DSSTDTC <- format(mdy(ds1$IT.DSSTDAT), "%Y-%m-%d")
  
  # oak_id_vars
  ds2 <- generate_oak_id_vars(ds1, pat_var = "PATNUM", raw_src = "ds_raw")
  
  # Identifiers
  ds3 <- ds2
  ds3$STUDYID <- studyid
  ds3$DOMAIN  <- "DS"
  ds3$USUBJID <- paste0(ds3$STUDYID, "-", ds3$patient_number)
  
  # VISIT / VISITNUM Darivation (Raw variable INSTANCE is used instead of EC_RAW.VISITNAM)
  ds4 <- ds3 %>%
    mutate(
      DSTERM  = IT.DSTERM,
      DSDECOD = IT.DSDECOD,
      DSCAT   = "DISPOSITION EVENT",
      
      # Derive VISIT and VISITNUM from INSTANCE
      VISIT_raw = toupper(trimws(INSTANCE)),
      
      VISIT = case_when(
        grepl("SCREEN|SCR", VISIT_raw)    ~ "SCREENING",
        grepl("BASE|BL", VISIT_raw)       ~ "BASELINE",
        grepl("WEEK|WK", VISIT_raw)       ~ VISIT_raw,
        grepl("EOS|END|TERMINATION", VISIT_raw) ~ "END OF STUDY",
        grepl("UNSCHED|UNSCH", VISIT_raw) ~ "UNSCHEDULED",
        TRUE                              ~ "END OF STUDY"
      ),
      
      VISITNUM = case_when(
        grepl("SCREEN|SCR", VISIT_raw)    ~ -1L,
        grepl("BASE|BL", VISIT_raw)       ~ 0L,
        grepl("WEEK|WK", VISIT_raw)       ~ as.numeric(gsub("\\D", "", VISIT_raw)),
        grepl("EOS|END|TERMINATION", VISIT_raw) ~ 99L,
        grepl("UNSCHED|UNSCH", VISIT_raw) ~ 98L,
        TRUE                              ~ 99L
      )
    )
  
  # Add DSSEQ
  ds5 <- ds4 %>%
    group_by(USUBJID) %>%
    arrange(DSSTDTC, DSTERM, na.last = TRUE) %>%
    mutate(DSSEQ = row_number()) %>%
    ungroup()
  
  # Derive DSSTDY
  ds <- derive_study_day(
    sdtm_in       = ds5,
    dm_domain     = dm,
    tgdt          = "DSSTDTC",
    refdt         = "RFSTDTC",
    study_day_var = "DSSTDY"
  ) %>%
    
    select(
      STUDYID, DOMAIN, USUBJID, DSSEQ, DSTERM, DSDECOD, DSCAT, VISITNUM, VISIT, DSDTC, DSSTDTC, DSSTDY
    )
  
  # Assign SDTM Variable labels
  ds <- set_variable_labels(ds,
                            STUDYID  = "Study Identifier",
                            DOMAIN   = "Domain Abbreviation",
                            USUBJID  = "Unique Subject Identifier",
                            DSSEQ    = "Sequence Number",
                            DSTERM   = "Reported Term for the Disposition Event",
                            DSDECOD  = "Standardized Disposition Term",
                            DSCAT    = "Category for Disposition Event",
                            VISITNUM = "Visit Number",
                            VISIT    = "Visit Name",
                            DSDTC    = "Date/Time of Collection",
                            DSSTDTC  = "Start Date/Time of Disposition Event",
                            DSSTDY   = "Study Day of Start of Disposition Event"
  )
  
  # Assign Dataset label
  attr(ds, "label") <- "DS - Subject Disposition Domain"
  
  message("✓ DS domain created (", nrow(ds), " rows)")
  return(ds)
}

# -----------------------------------------------------
# -----------------------------------------------------


# Macro call for Dataset Creation. 

dm <- create_dm_domain()
ds <- create_ds_domain(dm = dm)

# Create output directory [This is my posit.cloud configuration - may require change to execute]
output_dir <- "/cloud/project/question_2"

# Verify output directory exist
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

# Create clean_for_xpt function to create column names for XPT (replace dots with underscores. eg IT.DSDECOD)
clean_for_xpt <- function(df) {
  names(df) <- str_replace_all(names(df), "\\.", "_")
  df %>% select(-any_of(c("oak_id", "raw_source")))
}

# Create clean & compliant dataset
dm_clean <- clean_for_xpt(dm)
ds_clean <- clean_for_xpt(ds)

# Export to question_2 output directory
haven::write_xpt(dm_clean, file.path(output_dir, "dm.xpt"))
haven::write_xpt(ds_clean, file.path(output_dir, "ds.xpt"))




